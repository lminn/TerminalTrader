# #!/usr/bin/env python3

# from flask import Blueprint, render_template, request


# controller = Blueprint('featured',__name__,url_prefix='/featured')

# @controller.route('/',methods=['GET'])
# def show_featured():
#     return render_template('featured.html')


#!/usr/bin/env python3

from flask import Blueprint, render_template, request

from core import model


controller = Blueprint('featured',__name__,template_folder='templates',
                    static_folder='static')
#controller = Blueprint('general',__name__,url_prefix='')


@controller.route('/',methods=['GET'])
def show_login():
	return render_template('login.html')
