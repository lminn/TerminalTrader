#!/usr/bin/env bash

clear
echo ""
echo "Starting test server..."
echo ""
python3 run/wsgi.py
